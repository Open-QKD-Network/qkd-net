( ./src/Drivers/DummyQKDDriver/DummyQKDDriver -c dummy_A_B_B & ) && ( ./src/Drivers/DummyQKDDriver/DummyQKDDriver -c dummy_B_C_B & )
