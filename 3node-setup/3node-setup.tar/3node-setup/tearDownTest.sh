killall -9 SiteAgentRunner & killall -9 DummyQKDDriver & killall -9 java
